/*
	
	File: 		motor_directions.h
	Author: 	Daniel Busan
	Created:	May 2015
	Version: 	1.0
	
	Header file for the commands that handle the motor directions for the vehicle.
*/

/*
	Set motor direction forwards on backwards
*/
// void set_rmotor_forwards(void);
// void set_rmotor_reverse(void);

// void set_lmotor_forwards(void);
// void set_lmotor_reverse(void);

#ifndef _motor_directions_h
#define _motor_directions_h

typedef enum {
	LEFT, RIGHT
} motor_type;

typedef enum {
	FORWARDS, REVERSE
} motor_direction;

#ifdef __cplusplus
extern "C" {
#endif

long map(long x, long in_min, long in_max, long out_min, long out_max);

motor_direction get_motor_direction(int motor_speed); // function that takes in the motor

void set_pin_direction(motor_type mType, motor_direction mDir);

void set_motor_speed(motor_type mType, int motor_speed);

void setup_motor_pwm(motor_type mType, int motor_speed); // sets the PORTS

#ifdef __cplusplus
}
#endif

#endif
