/*
	
	File: 		motor_directions.h
	Author: 	Daniel Busan
	Created:	May 2015
	Version: 	1.0
	
	Source file containing the definitions of the functions handling the motor directions
*/

#include "motor_directions.h"
#include <Arduino.h>

// typedef enum motor {LEFT, RIGHT} motor_type;
// typedef enum direct {LEFT, RIGHT} motor_direction;

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

motor_direction get_motor_direction(motor_type mType, int motor_speed)
{
	
	if (motor_speed >= 0)
		return FORWARDS;
	else
		return REVERSE;

}

void set_motor_speed(motor_type mType, int motor_speed) // motor speed goes from 0 to 126
{
	
	if (mType == LEFT)
	{
		OCR1A = map(motor_speed, 0, 126, 0, 32000);
	}
	if (mType == RIGHT)
	{
		OCR1B = map(motor_speed, 0, 126, 0, 32000);
	}
}

void set_pin_direction(motor_type mType, motor_direction mDir)
{
  /*
	switch (mType)
	{
		case LEFT:
		if (mDir == FORWARDS) // set forwards direction
		{
			PORTA |= (1<<0); // digital pin 22 ON 
			PORTA &= ~(1<<1); // digital pin 23 OFF 		
		}
		else
		{
			// set reverse direction
			PORTA &= ~(1<<0);
			PORTA |= (1<<1); 
		}
		break;
		
		case RIGHT:
		if (mDir == FORWARDS) // set forwards direction for right motor
		{
			PORTA |= (1<<2); 
                        PORTA &= ~(1<<3);
                }
		
		else
		{	// set reverse direction
			PORTA &= ~(1<<2); 
                        PORTA |= (1<<3);
		}
		break;
	} */
}
/*

	this function is called in main(). It handles direction of each individual motor;
	This function receives a motor_type variable and an int16_t variable. It sets the PWM on the ports 
	

*/

void setup_motor_pwm(motor_type mType, int motor_speed) // sets the PORTS
{
	
	// SETUP PINS ON DDR FOR LEFT AND/OR RIGHT MOTOR
	motor_direction mDirection = get_motor_direction(mType, motor_speed);
	set_pin_direction(mType, mDirection); // sets ports 
	
	// ABSOLUTE VALUE
	if (motor_speed < 0)
		motor_speed = -motor_speed;
	
	if (motor_speed >= 126) 
	{
		set_motor_speed(mType, 126);
	}
	else if (motor_speed >= 0 && motor_speed < 126)
	{
		set_motor_speed(mType, motor_speed);
	}
}
