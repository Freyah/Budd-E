#include "autonomous.h"
#include "motor_directions.h"
#include "Arduino.h"
int current_millis = 0;

// Forward
void move_forward(void) 
{
  // RIGHT FORWARDS
  OCR1A = 9999;
  PORTA &= ~(1<<0); // digital pin 22 OFF
  PORTA |= (1<<1); // digital pin 23 ON // THEY'RE REVERSED WTF
  
  // LEFT FORWARDS
  OCR1B = 9999;
  PORTA |= (1<<2); 
  PORTA &= ~(1<<3);
  
  //setup_motor_pwm(LEFT, 0); //set left motor to max
  //setup_motor_pwm(RIGHT, 126); //set right motor to max

}

void turn_left(int turn_degrees)
{
	// !NEEDS EDITING
 
    if (turn_degrees == 90)
    {
        OCR1B = 4500; OCR1A = 9999;
        
        PORTA &= ~(1<<0); // digital pin 22 OFF - for right motor
        PORTA |= (1<<1); // digital pin 23 ON // THEY'RE REVERSED WTF

    }
    else 
    {
      OCR1B = 4500; OCR1A = 9999;
        
      PORTA &= ~(1<<0); // digital pin 22 OFF - for right motor
      PORTA |= (1<<1); // digital pin 23 ON // THEY'RE REVERSED WTF
      
      PORTA |= (1<<2); 
      PORTA &= ~(1<<3);
      //setup_motor_pwm(RIGHT, 126);
       //setup_motor_pwm(LEFT, 126-(turn_degrees)); // 5 degrees * 4 = 20 ms turn
    }
    //setup_motor_pwm(LEFT, 0);
    //setup_motor_pwm(RIGHT, 126);
}


void turn_right(int turn_degrees)
{
	// !NEEDS EDITING
   
    if (turn_degrees == 90)
    {
        OCR1A = 4500; OCR1B = 9999;
        
        PORTA &= ~(1<<3); // LEFT MOTOR CONTROL - FORWARDS
        PORTA |= (1<<2); // digital pin 23 ON // THEY'RE REVERSED WTF

    }
    else 
    {
      OCR1A = 4500; OCR1B = 9999;
        
      PORTA &= ~(1<<0); // digital pin 22 OFF - for right motor
      PORTA |= (1<<1); // digital pin 23 ON // THEY'RE REVERSED WTF
      
      PORTA |= (1<<2); 
      PORTA &= ~(1<<3);
      //setup_motor_pwm(RIGHT, 126);
       //setup_motor_pwm(LEFT, 126-(turn_degrees)); // 5 degrees * 4 = 20 ms turn
    }
    
}

void reverse(void)
{
    //setup_motor_pwm(LEFT, -126);
    //setup_motor_pwm(RIGHT, -126);
    
    OCR1A = 9999; OCR1B = 9999;
    PORTA |= (1<<0); // digital pin 22 OFF - for right motor
    PORTA &= ~(1<<1); // digital pin 23 ON // THEY'RE REVERSED WTF
      
    PORTA &= ~(1<<2); 
    PORTA |= (1<<3);
}

void stop_motors(void)
{
   OCR1A = 0; OCR1B = 0;
} 

